// Коды ошибок одинаковы при любом хранилище. Сообщение начинается с кода.
export type ErrorCode =
  | 'PERIOD_LOCKED' | 'PERIOD_NOT_AFTER_LOCK' | 'NOTHING_TO_REOPEN' | 'CHECKPOINT_MISMATCH'
  | 'INVALID_AMOUNT' | 'INVALID_SIGN' | 'INVALID_DATE' | 'INVALID_TIMEZONE' | 'INVALID_ORIGINAL'
  | 'INVALID_FIELD' | 'CURRENCY_MISMATCH' | 'ACCOUNT_ARCHIVED' | 'OPENING_EXISTS' | 'OPENING_NOT_ADJUSTMENT'
  | 'NOT_FOUND' | 'FORBIDDEN' | 'DUPLICATE_KEY' | 'CURRENCY_LOCKED'
  | 'IMPORT_INVALID' | 'IMPORT_DUPLICATE' | 'IMPORT_BLOCKED' | 'INVALID_STATE' | 'IDENTIFIER_OVERLAP' | 'IDENTIFIER_INVALID_RANGE' | 'CRYPTO_UNAVAILABLE' | 'NO_RATE'
  | 'STATEMENT_UNRECOGNIZED' | 'STATEMENT_PARSE' | 'COUNTERPARTY_FILE_INVALID' | 'RECONCILE_FAILED' | 'BALANCE_MISMATCH'

export class CoreError extends Error {
  constructor(public readonly code: ErrorCode, message: string, public readonly details?: Record<string, unknown>) {
    super(`${code}: ${message}`)
    this.name = 'CoreError'
  }
}
export const fail = (code: ErrorCode, message: string, details?: Record<string, unknown>): never => {
  throw new CoreError(code, message, details)
}
